package org.anderes.edu.dojo.rest;

import org.anderes.edu.dojo.rest.persistence.WeatherRepository;
import org.anderes.edu.dojo.rest.persistence.WeatherRepositoryStub;

public class WeatherResource {

    private WeatherRepository repository = WeatherRepositoryStub.INSTANCE;
    
   
}
